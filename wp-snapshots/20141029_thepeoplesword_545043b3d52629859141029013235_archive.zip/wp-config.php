<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress-db');

/** MySQL database username */
define('DB_USER', 'wordpress-user');

/** MySQL database password */
define('DB_PASSWORD', 'fidodido');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define(‘FS_METHOD’, ‘direct’);

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'lbKp0]sU/>zK]]{M<soGS`Q+qI;*N%8`A%MbOQ!oeqRt}0c#=ROupf5~qp]oi1k=');
define('SECURE_AUTH_KEY',  'J*!F!-hfU,f(G AXlIE8_p=d>Vtn}l7d}90`5|X2<c/4tJxx2f99u}(V;$jh>)h ');
define('LOGGED_IN_KEY',    '7+eFl-Kv[{44z|Z2i1(I|al%CQHSx/~>p;4){Tc;8Klus}#3>Z2lMjQ[<rMLIC]g');
define('NONCE_KEY',        'HUe*9M-!J`dYgZH|6dK`<1vpxAPtkm$,J5Zt$-R+Y]e9I!a/J-@ZF0+*~x*&$l8E');
define('AUTH_SALT',        'O-bUwZaK+!Br3<M$|J[9Cq:LDYpvz=u_/(|Z!Sy~eK _C/]m/`zDo3y6b*&+||KW');
define('SECURE_AUTH_SALT', '!d7pWR}+6q;6i;Iltk+q[2$.=aOL:.+yxprxPT:Ma$+!hsc6C`U6s}DE4m+TAR6h');
define('LOGGED_IN_SALT',   'lj7-|rZ5xZM7)i#mHwh.<DghZe3I3HD+y;gX7<yuOpKfkgF3,sjd -H5m`-)o26f');
define('NONCE_SALT',       'w@I0o%J%G^bl|*z`1K+Dg1n$_c-#zV?AZ5,G+8H[-waA+-z#dG#BRpQhYp5yi$o!');


/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);
define('WP_DEBUG_LOG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
